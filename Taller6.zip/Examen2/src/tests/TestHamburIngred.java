package tests;

import src.Hamburguesa;
import src.Ingrediente;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


public class TestHamburIngred {

	private Hamburguesa hambur1;
	
	@BeforeEach
	public void setUp() throws Exception {
		try {
			hambur1 = new Hamburguesa("Clasica", 50);
		} catch (Exception e) {
			
		}
	}
	
	//De crear rebaja
	@Test
	public void testRebajaMenor30() {
		hambur1.crear_rebaja(10);
		assertEquals(45, hambur1.getPrecio());
	}
	
	@Test
	public void testRebajaMayor30() {
		//caso igual 30
		hambur1.crear_rebaja(30);
		assertEquals(35, hambur1.getPrecio());
		//caso mayor 30
		hambur1.setPrecio(50);
		hambur1.crear_rebaja(40);
		assertEquals(35, hambur1.getPrecio());
	}
	
	//De aumentar prpecio
	@Test
	public void testAumentarPrecioCorrectamente() throws Exception {
		try {
			hambur1.aumentar_precio(60);
			assertEquals(60, hambur1.getPrecio());
		} catch (Exception e ){
			
		}
	}
	
	@Test
	public void testExcepcionFuncionaCuandoMuyCareros() {
		Exception excep = assertThrows(Exception.class, () -> {
			hambur1.aumentar_precio(200);
		});
		assertEquals("101 dólares por una cangreburguer!?", excep.getMessage());
	}
	
	//De agregar ingrediente
	@Test
	public void testAgregaIngrediente() throws Exception {
		try {
			Ingrediente tocino = new Ingrediente("Tocino", false);
			hambur1.agregar_ingrediente(tocino);
			
			assertTrue(hambur1.getIngredientes().contains(tocino));
		} catch (Exception e) {
			
		}
	}
	
	@Test
	public void testTamanioCambiaEn1AlAgregar1() throws Exception {
		try {
			Ingrediente tocino = new Ingrediente("Tocino", false);
			int tamInicial = hambur1.getIngredientes().size();
			hambur1.agregar_ingrediente(tocino);
			
			assertEquals(tamInicial+1, hambur1.getIngredientes().size());
		} catch (Exception e) {
			
		}
	}
	
	@Test
	public void testFallaSiAgrega7Ingrediente() throws Exception {
		try {
			for (int i=1; i<=7; i++) {
				hambur1.agregar_ingrediente(new Ingrediente("ingrediente " + i, true));
			}
			
			Exception excep = assertThrows(Exception.class, () -> {
				hambur1.agregar_ingrediente(new Ingrediente("ingrediente " + 7, true));
			});
			assertEquals("Esto no es Burgermaster, muchos ingredientes", excep.getMessage());
		} catch (Exception e) {
			
		}
	}
	
	//De Es vegana
	@Test
	public void testSoloIngredientesVeganos() throws Exception {
		try {
			hambur1.agregar_ingrediente(new Ingrediente("tomate", true));
			hambur1.agregar_ingrediente(new Ingrediente("carne de lentejas", true));
			assertTrue(hambur1.determinar_vegana());
		} catch (Exception e) {
			
		}
		
	}
	
	@Test
	public void testSoloIngredientesNoVeganos() throws Exception {
		try {
			hambur1.agregar_ingrediente(new Ingrediente("tocino", false));
			hambur1.agregar_ingrediente(new Ingrediente("huevo frito", false));
			assertFalse(hambur1.determinar_vegana());
		} catch (Exception e) {
			
		}
		
	}
	
	@Test
	public void testIngredientesMixtos() throws Exception {
		try {
			hambur1.agregar_ingrediente(new Ingrediente("tocino", false));
			hambur1.agregar_ingrediente(new Ingrediente("tomate", true));
			assertFalse(hambur1.determinar_vegana());
		} catch (Exception e) {
			
		}
		
	}
	
}
